import "./App.css";
import WebSearch from "./pages/WebSearch";

export default function App() {
  return (
    <div className="App">
      <main>
        <WebSearch />
      </main>
    </div>
  );
}
